package com.company;

import java.util.Scanner;

public class zadanie2 {


    public static void main(String[] args) {
        System.out.print("Ile znasz typów?");
        Scanner sc = new Scanner(System.in);
        Integer ile = sc.nextInt();
        System.out.print("Podaj wszystkie typy proste jakie znasz:");
        for(int i=0; i<ile; i++){
            String znam = sc.next();






        }




        }




}
