package com.company;

public class zadanie4 {
    public static void main(String[] args) {
        int ile = 0;
        for(int i = -1000; i<1001;i++){
            if(ile%3 == 0){
                System.out.print(i);

            }
            ile = ile + 1;


        }
    }

}
