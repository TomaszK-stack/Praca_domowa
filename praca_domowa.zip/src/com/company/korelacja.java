package com.company;

public class korelacja

{
    public static void main(String[] args){
        

    }
}
